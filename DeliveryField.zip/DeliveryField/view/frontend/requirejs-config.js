var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Custom_DeliveryField/js/model/shipping-save-processor/default'
        }
    }
};